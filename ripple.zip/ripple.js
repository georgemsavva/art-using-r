    
    
/*
This work was created by George Savva (Twitter @georgemsavva) and is released under a
Attribution-ShareAlike 4.0 International (CC BY-SA 4.0) license.  https://creativecommons.org/licenses/by-sa/4.0/

This is a human-readable summary of (and not a substitute for) the license. Disclaimer.
You are free to:

Share — copy and redistribute the material in any medium or format
Adapt — remix, transform, and build upon the material
    for any purpose, even commercially.
This license is acceptable for Free Cultural Works.
The licensor cannot revoke these freedoms as long as you follow the license terms.

Under the following terms:
    Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
    ShareAlike — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
    No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.
*/

    const canvas = document.querySelector('#output')
    const gl = canvas.getContext('webgl')
 
    var minsize;
    function resize() {
      canvas.width = window.innerWidth 
      canvas.height = window.innerHeight 
      minsize = Math.min(canvas.width, canvas.height)
    }

    resize()
    window.addEventListener('resize', resize)
  
const vertexShaderSource = `
attribute vec2 aVertexPosition;

void main() {
    gl_Position = vec4(aVertexPosition.x/1.0,aVertexPosition.y/1.0, 0.0, 1.0);
}`

var fragmentShaderSource = `
#ifdef GL_ES
precision highp float;
#endif
       
uniform float uTime;
uniform vec2 uPosition;
uniform float dimx;
uniform float dimy;
uniform float f1;
uniform float f2;
uniform float f3;
uniform float f4;
uniform float a1;
uniform float a2;
uniform float a3;
uniform float a4;
uniform float speed1;
uniform float speed2;

uniform int colorScheme;

#define PI 3.14159

vec3 vColor;
vec3 hsv2rgb( in vec3 c )
{
    vec3 rgb = clamp( abs(mod(c.x*6.0+vec3(0.0,4.0,2.0),6.0)-3.0)-1.0, 0.0, 1.0 );
	return c.z * mix( vec3(1.0), rgb, c.y);
}
void main()
{
    float scale = 0.5;
    float x=(PI*scale*(gl_FragCoord.x - dimx/2.0)/dimy);
    float y=(PI*scale*(gl_FragCoord.y - dimy/2.0)/dimy);
    float intensity = 5.0*(0.4-(x*x)-(y*y))*
      abs(sin(x+speed1*uTime/100.0)*a1*sin(f1*x)*sin(f1*y) +     
      sin(y+speed2*uTime/200.0)*a2*sin(f2*x)*sin(f2*y) +  
      a3*sin(f4*x+speed2*uTime/100.0)*sin(f3*y)+
      a4*sin(f3*x)*sin(f4*y+speed2*uTime/100.0));
    float v=pow(sin(x+intensity+uTime/300.0),4.0);
    float s=mod(x*y+intensity+uTime/1000.0,1.0);
    float st=mod(intensity,1.0);
    vColor=hsv2rgb(vec3(
        mod(uTime*0.001+x*x+y*y+intensity*0.2,1.0),
        0.8-(x*x+y*y),
        v));
    if(mod(float(colorScheme),2.0)>0.5) vColor.x=min(vColor.z, vColor.y);
    if(mod(float(colorScheme),4.0)>1.0) vColor.y=min(vColor.z, vColor.x);
    if(mod(float(colorScheme),8.0)>3.0) vColor.z=min(vColor.x, vColor.y);
    gl_FragColor=vec4(vColor,1.0);
}`;

    const vertexShader = gl.createShader(gl.VERTEX_SHADER)
    gl.shaderSource(vertexShader, vertexShaderSource)
    gl.compileShader(vertexShader)

    const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER)
    gl.shaderSource(fragmentShader, fragmentShaderSource)
    gl.compileShader(fragmentShader)

    const program = gl.createProgram()
    gl.attachShader(program, vertexShader)
    gl.attachShader(program, fragmentShader)
    gl.linkProgram(program)

    const PI = 3.14159;
    const vertices = new Float32Array([
      -1,
      1,
      1,
      1,
      1,
      -1,
      -1,
      1,
      1,
      -1,
      -1,
      -1,
    ])
    
    const itemSize = 2
    const numItems = vertices.length / itemSize

    const vertexBuffer = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer)
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW)
    gl.bindBuffer(gl.ARRAY_BUFFER, null);
    gl.useProgram(program)
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    var coord = gl.getAttribLocation(program, "aVertexPosition");
    gl.vertexAttribPointer(coord, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(program.aVertexPosition);
    var speed1, speed2,f1, f2,f3,f4,a1,a2,a3,a4,colorScheme;
    do{ f1 =  Math.floor(fxrand()*20)+1;}while(f1<1);
    do{ f2 =  Math.floor(fxrand()*6) + 1;}while(f2<1);
    do{ f3 =  Math.floor(fxrand()*8)+1;}while(f3<3);
    do{ f4 =  Math.floor(fxrand()*4)+1;}while(f4<0);
    a1 =  fxrand()*3
    a2 =  fxrand()*3
    a3 =  fxrand()*3
    a4 =  fxrand()*3
    speed1 =  0.3+fxrand();
    speed2 =  0.3+fxrand();
    var colorScheme = Math.floor(fxrand()*8);
    
    function render() {
    
      minsize = Math.min(canvas.width, canvas.height);
      gl.viewport(0, 0, canvas.width, canvas.height);

      gl.clearColor(.00,.00,.0, 0)

      gl.enable(gl.DEPTH_TEST);
      gl.clear(gl.COLOR_BUFFER_BIT)
      const scale=2.0     
      program.uTime = gl.getUniformLocation(program, 'uTime');
      gl.uniform1f(program.uTime, 0.1 * performance.now());

      gl.uniform1f(gl.getUniformLocation(program, 'dimx'), canvas.width)
      gl.uniform1f(gl.getUniformLocation(program, 'dimy'), canvas.height)
      gl.uniform1f(gl.getUniformLocation(program, 'f1'), scale*f1)
      gl.uniform1f(gl.getUniformLocation(program, 'f2'), scale*f2)
      gl.uniform1f(gl.getUniformLocation(program, 'f3'), scale*f3)
      gl.uniform1f(gl.getUniformLocation(program, 'f4'), scale*f4)
      gl.uniform1f(gl.getUniformLocation(program, 'a1'), a1)
      gl.uniform1f(gl.getUniformLocation(program, 'a2'), a2)
      gl.uniform1f(gl.getUniformLocation(program, 'a3'), a3)
      gl.uniform1f(gl.getUniformLocation(program, 'a4'), a4)
      gl.uniform1f(gl.getUniformLocation(program, 'speed1'), speed1)
      gl.uniform1f(gl.getUniformLocation(program, 'speed2'), speed2)
      gl.uniform1i(gl.getUniformLocation(program, 'colorScheme'), colorScheme )

      gl.drawArrays(gl.TRIANGLES, 0, numItems);
      
      requestAnimationFrame(render)
    }
    resize()
    render()

